# Foster CRM



## Requirements

This plugin requires Craft CMS 5.5.0 or later, and PHP 8.2 or later.

