<?php

namespace foster\fostercrm;

use Craft;
use craft\base\Plugin as BasePlugin;

/**
 * Foster CRM plugin
 */
class Plugin extends BasePlugin
{
    public string $schemaVersion = '1.0.0';

    public function init(): void
    {
        parent::init();

        // Register console namespace for CLI commands
        if (Craft::$app->getRequest()->getIsConsoleRequest()) {
            $this->controllerNamespace = 'foster\fostercrm\console';
        }

        Craft::info(
            Craft::t(
                'fostercrm',
                '{name} plugin loaded',
                ['name' => $this->name]
            ),
            __METHOD__
        );
    }
}
