<?php

namespace foster\fostercrm\console;

use Craft;
use League\Csv\Reader;
use yii\console\Controller;

class ImportCommand extends Controller
{
    /**
     * Import customers from customers.csv.
     */
    public function actionImportCustomers()
    {
        $filePath = Craft::$app->getPath()->getStoragePath() . '/csv/customers.csv';

        if (!file_exists($filePath)) {
            $this->stderr("Error: customers.csv file not found!\n");
            return 1; // Exit with error
        }

        $reader = Reader::createFromPath($filePath, 'r');
        $reader->setHeaderOffset(0);
        $records = $reader->getRecords();

        foreach ($records as $row) {
            // Here you can process each customer record
            $this->stdout("Importing customer: " . $row['name'] . "\n");
        }

        $this->stdout("Customer data imported successfully!\n");
        return 0; // Exit successfully
    }
}
